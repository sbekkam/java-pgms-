package com.cg.banking.services;
import java.util.List;

import javax.naming.spi.InitialContextFactoryBuilder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
@Component(value="bankingServices")
public class BankingServicesImpl implements BankingServices{
	@Autowired
	private BankingDAOServices bankingDAOServices;
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return bankingDAOServices.insertCustomer(new Customer(firstName, lastName, emailId, panCard, new Address(homeAddressPinCode, homeAddressCity, homeAddressState),new Address(localAddressPinCode, localAddressCity, localAddressState)));
	}
	@Override
	public long openAccount(int customerId, String accountType, float initBalance) throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equalsIgnoreCase("current")){
			if(initBalance<=0)
				throw new InvalidAmountException("The given amount for initial balance is inavlid. Please input vaild initial balance");
			return bankingDAOServices.insertAccount(customerId, new Account(accountType, initBalance));
		}
		throw new InvalidAccountTypeException("Account Tpye must be Valid");
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo).getStatus().equals("Blocked"))
			throw new AccountBlockedException("The Account of customerId"+customerId+"accountNo"+accountNo+"is Blocked");
		if(amount<=0)
			throw new InvalidAmountException("Enter Valid Amount to Deposit");
		if(bankingDAOServices.getAccount(customerId, accountNo).getStatus().equalsIgnoreCase("Active")){
			Account account=getAccountDetails(customerId, accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
		bankingDAOServices.insertTransaction(customerId, accountNo,new Transaction(amount, "Deposit"));
		bankingDAOServices.updateAccount(customerId, account);
		return  bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance();
		}
		else
			throw new AccountBlockedException("Account is Blocked,Kindly Update Status");
	}
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException {
		if(amount<=0)
			throw new InvalidAmountException("Enter correct amount");
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo).getPinNumber()==pinNumber){
			if(bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance()-amount>=0){
				Account account = getAccountDetails(customerId, accountNo);
				account.setAccountBalance(account.getAccountBalance()-amount);
				bankingDAOServices.insertTransaction(customerId, accountNo,new Transaction(amount, "WithDraw"));
				bankingDAOServices.updateAccount(customerId, account);
			}
			else
				throw new InsufficientAmountException("Given ammount is not sufficient to withdraw");
		}
		else
			throw new InvalidPinNumberException("Enter Valid Pin Number");
		return bankingDAOServices.getAccount(customerId, accountNo).getAccountBalance();	

	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		if(bankingDAOServices.getAccount(customerIdFrom, accountNoFrom).getPinNumber()==pinNumber){
			withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
			depositAmount(customerIdTo, accountNoTo, transferAmount);
		}
		else
			throw new InvalidPinNumberException("Enter Valid Pin Number");
		return true;
	}
	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		Customer customer = bankingDAOServices.getCustomer(customerId);
		return customer;
	}
	@Override
	public Account getAccountDetails(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		Account account = bankingDAOServices.getAccount(customerId, accountNo);
		return account;
	}
	@Override
	public int generateNewPin(int customerId, long accountNo)
			throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		return bankingDAOServices.generatePin(customerId,bankingDAOServices.getAccount(customerId, accountNo));
	}
	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		else if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		else if(oldPinNumber==bankingDAOServices.getAccount(customerId, accountNo).getPinNumber()){
			Account account = bankingDAOServices.getAccount(customerId, accountNo);
			account.setPinNumber(newPinNumber);
			bankingDAOServices.updateAccount(customerId, account);
			return true;
		}
		else
			throw new InvalidPinNumberException("The given pin is not valid");
	}
	@Override
	public  List<Customer> getAllCustomerDetails() throws BankingServicesDownException {
		return bankingDAOServices.getCustomers();
	}
	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId)
			throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		return bankingDAOServices.getAccounts(customerId);
	}
	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		return bankingDAOServices.getTransactions(customerId, accountNo);
	}
	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		return bankingDAOServices.getAccount(customerId, accountNo).getStatus();
	}
	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		if(bankingDAOServices.getAccount(customerId, accountNo)==null)
			throw new AccountNotFoundException("Account with customerId "+customerId+" accountNo"+accountNo+"not Found");
		bankingDAOServices.deleteAccount(customerId, accountNo);
		return true;
	}
	@Override
	public boolean removeCustomer(int customerId) throws BankingServicesDownException, CustomerNotFoundException {
		if(bankingDAOServices.getCustomer(customerId)==null)
			throw new CustomerNotFoundException("Customer"+customerId+"not Found");
		return bankingDAOServices.deleteCustomer(customerId);
	}
}
