package com.cg.banking1.daoservices;


import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking1.utility.*;
import com.cg.banking1.beans.*;
@Component(value = "bankingDAOServices")
public class BankingDAOServicseImpl implements BankingDAOServices {
	@Autowired
	private	SessionFactory sessionFactory;
	private org.hibernate.Transaction tx;
	private Session session;
	@Override
	public int insertCustomer(Customer customer) {

		try {
			Session session = sessionFactory.openSession();
			tx = session.beginTransaction();
			int custId= (int) session.save(customer);
			tx.commit();
			return custId;

		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally {
			//session.close();
		}

	}

	@Override
	public long insertAccount(int customerId, Account account) {
		
		try {
			Session session= sessionFactory.openSession();
			tx = session.beginTransaction();
			Customer customer = getCustomer(customerId);
			account.setCustomer(customer);
			long accountNo= (long) session.save(account);
			tx.commit();
			return accountNo;
		} catch (HibernateException e) {
			if(tx!=null)
				tx.rollback();
			e.printStackTrace();
			throw e;
		}
		finally {
			//session.close();
		}
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		try {
			Session session= sessionFactory.openSession();
			tx = session.beginTransaction();
			Account account = getAccount(customerId, accountNo);
			transaction.setAccount(account);
			tx.commit();
			return true;
		} catch (HibernateException e) {
			if(tx!=null)
				tx.rollback();
			e.printStackTrace();
			throw e;
		}
		finally {
			//session.close();
		}
	}

		
	

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		Session session= sessionFactory.openSession();
		Customer customer= (Customer) sessionFactory.openSession().get(Customer.class, customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getCustomers() {
		Session session= sessionFactory.openSession();
		Query query = session.createQuery("from Customer");
		return query.list();
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}


	/*public static HashMap<Integer, Customer>  customers = new  HashMap<>();
	//private static int  CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111,TRANSACTION_ID_COUNTER=1;
	//private static int  CUSTOMER_IDX=0;

	public int insertCustomer(Customer customer) {
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		customers.put(customer.getCustomerId(), customer);
		return  customer.getCustomerId();

	}
	public long insertAccount(int customerId,Account account) {

		account.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);		
		return account.getAccountNo();

	}

	@Override
	public boolean updateAccount(int customerId, Account account) {

		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);	
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random random=new Random();
		account.setPinNumber(random.nextInt(10000));
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return account.getPinNumber();

	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {

		transaction.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);
		if(getAccount(customerId, accountNo)!=null){
		getAccount(customerId, accountNo).getTransactions().put((long) transaction.getTransactionId(), transaction);
		return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		customers.remove(customerId);
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		getCustomer(customerId).getAccounts().remove(accountNo);
		return false;


	}

	@Override
	public Customer getCustomer(int customerId) {
		return customers.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {		

		return customers.get(customerId).getAccounts().get(accountNo);
	}

	@Override
public List<Customer> getCustomers() {

		return new ArrayList<>(customers.values());
	}
	@Override
	public List<Account> getAccounts(int customerId) {

		return new ArrayList<>(customers.get(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());

	}*/
}
