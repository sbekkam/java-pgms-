package com.cg.banking1.utility;

import java.util.Random;

public class BankingUtility {
	public static int CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111,TRANSACTION_ID_COUNTER=1;
	public static Random rand = new  Random();

}
