package com.cg.banking1.daoservices;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking1.utility.*;

import com.cg.banking1.beans.*;
@Component(value = "bankingDAOServices")
public class BankingDAOServicseImpl implements BankingDAOServices {
	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;
	
	@Override
	public int insertCustomer(Customer customer) {
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer = getCustomer(customerId);
		account.setCustomer(customer);
		entityManager.persist(account);
		account.setStatus("active");
		entityManager.flush();
		entityManager.getTransaction().commit();
		return account.getAccountNo();
		
		
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Customer customer = getCustomer(customerId);
		account.setCustomer(customer);
		entityManager.merge(account);
		account.setStatus("active");
		entityManager.flush();
		entityManager.getTransaction().commit();
		return true;
		
		
	}

	@Override
	public int generatePin(int customerId, Account account) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
				entityManager.getTransaction().begin();
				Account account1=entityManager.find(Account.class, account.getAccountNo());
				account1.setPinNumber(BankingUtility.rand.nextInt(9999));
				updateAccount(customerId, account1);
				entityManager.flush();
				entityManager.getTransaction().commit();
				entityManager.close();
				return account1.getPinNumber();  
		
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Account account = getAccount(customerId, accountNo);
		transaction.setAccount(account);
		entityManager.persist(transaction);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		EntityManager entityManager= entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
				Customer customer= entityManager.find(Customer.class,customerId);
				entityManager.remove(customer);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return false;
		
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
	EntityManager entityManager = entityManagerFactory.createEntityManager();
	return entityManager.find(Customer.class,customerId);
	
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Account.class, accountNo);
	
	}

	@Override
	public List<Customer> getCustomers() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		TypedQuery<Customer> query = entityManager.createQuery("from Customer",Customer.class);
		return query.getResultList();
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		TypedQuery<Account> query = entityManager.createQuery("from Account",Account.class);
		return  query.getResultList();
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		TypedQuery<Transaction> query = entityManager.createQuery("from Transaction",Transaction.class);
		return  query.getResultList();
	}
	
}	
	
