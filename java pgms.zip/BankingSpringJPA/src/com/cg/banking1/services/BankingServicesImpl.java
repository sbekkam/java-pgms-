package com.cg.banking1.services;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking1.beans.Account;
import com.cg.banking1.beans.Address;
import com.cg.banking1.beans.Customer;
import com.cg.banking1.beans.Transaction;
import com.cg.banking1.daoservices.BankingDAOServices;
import com.cg.banking1.daoservices.BankingDAOServicseImpl;
import com.cg.banking1.exceptions.AccountBlockedException;
import com.cg.banking1.exceptions.AccountNotFoundException;
import com.cg.banking1.exceptions.BankingServicesDownException;
import com.cg.banking1.exceptions.CustomerNotFoundException;
import com.cg.banking1.exceptions.InsufficientAmountException;
import com.cg.banking1.exceptions.InvalidAccountTypeException;
import com.cg.banking1.exceptions.InvalidAmountException;
import com.cg.banking1.exceptions.InvalidPinNumberException;


@Component(value = "bankingServices")
public class BankingServicesImpl implements BankingServices {

	@Autowired
	private BankingDAOServices daoservices;


	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BankingServicesDownException {
		return daoservices.insertCustomer(new Customer(firstName, lastName, emailId, panCard,new Address(localAddressPinCode, localAddressCity, localAddressState),new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));		

	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance)throws InvalidAmountException,
	CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(accountType.equalsIgnoreCase("salary")||accountType.equalsIgnoreCase("savings")||accountType.equals("current")) {
			if(initBalance<100) throw new InvalidAmountException("Invalid amount. Please give above 100");
			return daoservices.insertAccount(customerId, new Account(accountType, initBalance));
		}
		throw new InvalidAccountTypeException("The given account type is not supported");
	}	


	@Override
	public float depositAmount(int customerId, long accountNo, float amount) throws CustomerNotFoundException,
	AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found"); 
		if(daoservices.getAccount(customerId, accountNo).getStatus().equalsIgnoreCase("active")) {

			Account account=daoservices.getAccount(customerId, accountNo);
			account.setAccountBalance(account.getAccountBalance()+amount);
			daoservices.updateAccount(customerId, account); 


		//	daoservices.getAccount(customerId, accountNo).setAccountBalance( daoservices.getAccount(customerId, accountNo).getAccountBalance()+amount);
			daoservices.insertTransaction(customerId, accountNo, new Transaction(amount, "Deposit"));
			return  daoservices.getAccount(customerId, accountNo).getAccountBalance();
		}
		throw new AccountBlockedException("Your Account has been blocked due to many attempts");	

	}
	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber)
			throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException,
			InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {

		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found"); 
		if(daoservices.getAccount(customerId, accountNo).getStatus().equalsIgnoreCase("blocked")) throw new AccountBlockedException("Account Blocked");
		if(daoservices.getAccount(customerId, accountNo).getPinNumber()==pinNumber) {
			if (amount>0&&amount<getAccountDetails(customerId, accountNo).getAccountBalance()) {
			
				
				getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()-amount);
				Account account=daoservices.getAccount(customerId, accountNo);
				account.setPinCounter(0);
				account.setAccountBalance(account.getAccountBalance()-amount);
				daoservices.updateAccount(customerId, account);

				daoservices.insertTransaction(customerId, accountNo, new Transaction(amount, "Withdrawl"));
				return getAccountDetails(customerId, accountNo).getAccountBalance();	
			} 
			else
				throw new InsufficientAmountException("Insufficient balance");
		}
		else {
			getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			if(daoservices.getAccount(customerId, accountNo).getPinCounter()==3) {				
				getAccountDetails(customerId, accountNo).setStatus("blocked");
			}	
		}throw new InvalidPinNumberException("Invalid Pin");
	}		

	 
		
	/*	getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()-amount);
						Account account=daoservices.getAccount(customerId, accountNo);
						account.setPinCounter(0);
						account.setAccountBalance(account.getAccountBalance()-amount);
						daoservices.updateAccount(customerId, account); */
		 

	
	
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) throws InsufficientAmountException, CustomerNotFoundException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {

		withdrawAmount(customerIdFrom, accountNoFrom, transferAmount, pinNumber);
		depositAmount(customerIdTo, accountNoTo, transferAmount);
		return true;
	}

	@Override
	public Customer getCustomerDetails(int customerId) throws CustomerNotFoundException, BankingServicesDownException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		return daoservices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found"); 
		return daoservices.getAccount(customerId, accountNo);

	}

	@Override
	public int generateNewPin(int customerId, long accountNo) throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found");
		Account account=daoservices.getAccount(customerId, accountNo);
		return daoservices.generatePin(customerId, account);
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber)
			throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found"); 	
		if(daoservices.getAccount(customerId, accountNo).getPinNumber()==oldPinNumber) { 		
			getAccountDetails(customerId, accountNo).setPinNumber(newPinNumber);
			return true;
		}
		else throw new InvalidPinNumberException("Invalid old pin,Enter correct old pin");

	}


	@Override
	public List<Customer> getAllCustomerDetails() throws BankingServicesDownException {

		return daoservices.getCustomers();
	}

	@Override
	public List<Account> getcustomerAllAccountDetails(int customerId) throws BankingServicesDownException, CustomerNotFoundException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		return daoservices.getAccounts(customerId);
	}

	@Override
	public List<Transaction> getAccountAllTransaction(int customerId, long accountNo) throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found"); 	
		return daoservices.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) throws BankingServicesDownException,
	CustomerNotFoundException, AccountNotFoundException, AccountBlockedException {
		if(daoservices.getCustomer(customerId)==null) throw new CustomerNotFoundException("Custoemr with id="+customerId+" "+"Not found");
		if(daoservices.getAccount(customerId, accountNo)==null) throw new AccountNotFoundException("Account with A/C No:"+accountNo +"Not Found"); 	
		if(daoservices.getAccount(customerId, accountNo).getStatus().equalsIgnoreCase("blocked")) throw new AccountBlockedException("Account Blocked");
		return daoservices.getAccount(customerId, accountNo).getStatus();
	}

	@Override
	public boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException {

		return daoservices.deleteAccount(customerId, accountNo);
	}

}
