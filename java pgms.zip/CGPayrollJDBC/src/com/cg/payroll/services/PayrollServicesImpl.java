package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.*;
@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	@Autowired
	private PayrollDAOServices payrollDAOServices;
	@Override
	public int acceptAssociate(int yearlyInvestmentUnder80C,String firstName, String lastName, 
			String department, String designation, String pancard, String emailId,
			int basicSalary, int epf, int companyPf,
			int accountNumber,String bankName, String ifscCode) throws InvalidDataException, PayrollServicesDownException{
		if(yearlyInvestmentUnder80C<0)
			throw new InvalidDataException("Enter valid positive Yearly Investment");
		if(basicSalary<0)
			throw new InvalidDataException("Enter valid positive BasicSalary");
		if( epf<0)
			throw new InvalidDataException("Enter valid positive Epf");
		if(companyPf<0)
			throw new InvalidDataException("Enter valid positive CompanyPf");
		try {
			return payrollDAOServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES DOWN");
		}
	}
	@Override
	public boolean doUpdateAssociate(int associateId,int yearlyInvestmentUnder80C,String firstName, String lastName, 
			String department, String designation, String pancard, String emailId,
			int basicSalary, int epf, int companyPf,
			int accountNumber,String bankName, String ifscCode)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		try {
			if (payrollDAOServices.getAssociate(associateId)==null)
				throw new AssociateDetailsNotFoundException("Associate with associateId "+associateId+"not found");
		} catch (SQLException e1) {
			e1.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
		try {
			return payrollDAOServices.updateAssociate(new Associate(associateId,yearlyInvestmentUnder80C,firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
	}
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		if(getAssociateDetails(associateId)==null)
			throw new AssociateDetailsNotFoundException("Associate with associateId "+associateId+"not found");
		double personalAllowance,conveyanceAllowance,otherAllowance,grossSalary,annualSalary,tax,epf,companypf,basicSalary,yearlyInvestmentUnder80C,i,j;
		Associate associate;
		try {
			associate = payrollDAOServices.getAssociate(associateId);
			System.out.println(associate);
		} catch (SQLException e1) {
			e1.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");	
		}
		epf=associate.getSalary().getEpf();
		basicSalary=associate.getSalary().getBasicSalary();
		companypf=associate.getSalary().getCompanyPf();
		yearlyInvestmentUnder80C=associate.getYearlyInvestmentUnder80C();
		personalAllowance=0.3*basicSalary;
		conveyanceAllowance=0.2*basicSalary;
		otherAllowance=0.1*basicSalary;
		grossSalary=basicSalary+(0.25*basicSalary)+personalAllowance+conveyanceAllowance+otherAllowance+companypf;
		annualSalary=grossSalary*12;
		associate.getSalary().setHra((0.25*basicSalary));
		associate.getSalary().setGratuity((0.05*basicSalary));
		associate.getSalary().setConveyenceAllowance(conveyanceAllowance);
		associate.getSalary().setGrossSalary(grossSalary);
		associate.getSalary().setOtherAllowance(otherAllowance);
		associate.getSalary().setPersonalAllowance(personalAllowance);
		j=yearlyInvestmentUnder80C+12*(companypf+epf);	
		if(j>=150000)
			j=150000;
		if(annualSalary<250000){
			associate.getSalary().setMonthlyTax(0);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			try {
				payrollDAOServices.updateAssociate(associate);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
			}
			return (grossSalary-epf-companypf);
		}
		else if(annualSalary>=250000&&annualSalary<500000){
			i=(annualSalary-250000-j);
			if(i<=0)
				tax=0;
			else
				tax=(0.1*i)/12;
			associate.getSalary().setMonthlyTax(tax);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			try {
				payrollDAOServices.updateAssociate(associate);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
			}
			return (grossSalary-epf-companypf-tax);
		}
		else if(annualSalary>=500000&&annualSalary<1000000){
			i=(250000-j)*0.1;
			tax=(((annualSalary-500000)*0.2)+i)/12;
			associate.getSalary().setMonthlyTax(tax);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			try {
				payrollDAOServices.updateAssociate(associate);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
			}
			return (grossSalary-epf-companypf-tax);
		}
		else if(annualSalary>=1000000){
			i=(250000-j)*0.1;
			tax=(i+100000+((annualSalary-1000000)*0.3))/12;
			associate.getSalary().setMonthlyTax(tax);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			try {
				payrollDAOServices.updateAssociate(associate);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
			}
			return (grossSalary-epf-companypf-tax);
		}
		return 0;
	}
	@Override
	public boolean doDeleteAssociate(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		try {
			if(payrollDAOServices.getAssociate(associateId)==null)
				throw new AssociateDetailsNotFoundException("Associate with asssociateId "+associateId+"not found");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
		try{
			return payrollDAOServices.deleteAssociate(associateId);
		}catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
	}
	@Override
	public Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		try {
			if(payrollDAOServices.getAssociate(associateId)==null)
				throw new AssociateDetailsNotFoundException("Associate with associateId "+associateId+"not found");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
		try {
			return payrollDAOServices.getAssociate(associateId);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
	}
	@Override
	public List<Associate> getAllAssociateDetails() throws  PayrollServicesDownException{
		try{
			return payrollDAOServices.getAssociates();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("PAYROLL SERVICES ARE DOWN");
		}
	}
}