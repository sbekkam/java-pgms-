package com.cg.payroll.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidDataException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String args[]) throws PayrollServicesDownException, InvalidDataException, AssociateDetailsNotFoundException{
	 ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices= (PayrollServices) applicationContext.getBean("payrollServices");
		int associateId=payrollServices.acceptAssociate(150000, "Poornima", "Bandi", "Java", "SrCon", "pfnj678", "pony@gmail", 30000, 1000, 1000, 8986743, "icici", "icic9033");
		System.out.println("connection obtained");
		System.out.println(associateId);
		payrollServices.doUpdateAssociate(associateId,150000, "Dileep", "Bandi", "Java", "SrCon", "pfnj678", "pony@gmail", 30000, 1000, 1000, 8986743, "icici", "icic9033");	
		System.out.println("----Updating Record with ID =  -----" +associateId );
		payrollServices.doUpdateAssociate(associateId,150000, "Dileep", "Bandi", "Java", "SrCon", "pfnj678", "pony@gmail", 55000, 1000, 1000, 8986743, "icici", "icic9033");	
		System.out.println("----Updating Record with ID =  -----" +associateId );
		payrollServices.doUpdateAssociate(associateId,150000, "Dileep", "Bandi", "Java", "SrCon", "pfnj678", "pony@gmail", 30000, 1000, 1000, 8986743, "SD", "icic9033");	
		System.out.println("----Updating Record with ID =  -----" +associateId );
		payrollServices.doDeleteAssociate(associateId);
		System.out.println("----Updating Record with ID =  -----" +associateId );
		payrollServices.getAssociateDetails(31);
		System.out.println("----Getting Record with ID =  -----" +31 );
		payrollServices.getAllAssociateDetails();
		
		 
		 
		 
		
		
		/*try{ 
			System.oiop[ut.println(payrollServices.acceptAssociate(150000, "Poornima", "bandi", "java", "developer", "c345cc", "pony@gmail.com", 50000, 1000,1000,13567899, "HDFC", "HD00978"));
			System.out.println(payrollServices.acceptAssociate(20000, "Dileep", "godishala", "ADM", "Sr Con", "po674cc", "dileep@gmail.com", 30000, 2000, 200,13567899, "HDFC", "H780978"));
			System.out.println(payrollServices.acceptAssociate(20000, "Dil", "Pony", "ADM", "training", "thy765t", "dilpony@gmail.com", 30000, 2000, 200,13567899, "HDFC", "HD234978"));
			payrollServices.calculateNetSalary(1);
		}
		catch(PayrollServicesDownException e){
			e.printStackTrace();
			
			System.out.println(e);
		}
		catch(Exception e){
			e.printStackTrace();
		}*/
	}
}
