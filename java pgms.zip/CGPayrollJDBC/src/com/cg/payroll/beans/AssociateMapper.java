package com.cg.payroll.beans;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class AssociateMapper implements RowMapper<Associate> {

	@Override
	public Associate mapRow(ResultSet rs, int rowNum) throws SQLException {
		Associate associate = new Associate();
		associate.setAssociateId(rs.getInt("associateId"));
		associate.setYearlyInvestmentUnder80C(rs.getInt("yearlyInvestmentUnder80C"));
		associate.setFirstName(rs.getString("firstName"));  
		associate.setLastName(rs.getString("lastName"));
		associate.setDepartment(rs.getString("department"));
		associate.setDesignation(rs.getString("designation"));
		associate.setPancard(rs.getString("pancard"));
		associate.setEmailId(rs.getString("emailId"));
		return associate;
	}

}
