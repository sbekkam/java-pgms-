package com.cg.payroll.daoservices;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.SQLException;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.PayrollServicesDownException;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public PayrollDAOServicesImpl() throws PayrollServicesDownException {	
	}
	@Override
	public int insertAssociate(Associate associate) throws SQLException {	
		
		String sql = "insert into associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId)values(?,?,?,?,?,?,?)";
		int associateId=jdbcTemplate.update(sql, new Object[] {associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId()});
		
		String sql1 ="select max(associateId) from associate";
		int associateId1=jdbcTemplate.queryForObject(sql1, Integer.class);
		
		 String sql2="insert into salary(associateID,basicSalary,epf,companyPf) value(?,?,?,?)";
		 jdbcTemplate.update(sql2, new Object[] {associateId1,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf()});
		
		 
		 String sql3="insert into bankdetails(associateID,accountNumber,bankName,ifscCode)value(?,?,?,?)";
		 jdbcTemplate.update(sql3,new Object[] {associateId1,associate.getBankdetails().getAccountNumber(),associate.getBankdetails().getBankName(),associate.getBankdetails().getIfscCode()});
		 return associateId1;
	}
	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		String sql = "update associate set firstName = ? where associateId = ?";
		jdbcTemplate.update(sql, associate.getFirstName(),associate.getAssociateId());
		System.out.println("Updated Record with ID = " + associate.getAssociateId() );
		
		String sql1="update salary set basicSalary = ? where associateId = ?";
		jdbcTemplate.update(sql1, associate.getSalary().getBasicSalary(),associate.getAssociateId());
		System.out.println("Updated Record with ID = " + associate.getAssociateId() );
		
		String sql2="update bankdetails set bankName = ? where associateId = ?";
		jdbcTemplate.update(sql2, associate.getBankdetails().getBankName(),associate.getAssociateId());
		System.out.println("Updated Record with ID = " + associate.getAssociateId() );
		return false;
	}

	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		String sql = "delete from associate where associateId = ?";
		System.out.println("Deleted Record with ID = " + associateId);
		return false;
	}

	@Override
	public Associate getAssociate(int associateId) throws SQLException {
		String sql = "select * from associate where associateId = ?";
		Associate associate = jdbcTemplate.queryForObject(sql, new Object[]{associateId}, new AssociateMapper());
		return associate;

	}

	@Override
	public List<Associate> getAssociates() throws SQLException {
		String sql ="select * from associate";
		return  jdbcTemplate.query(sql, new AssociateMapper());
		 
	}
	/*@Override
	public int insertAssociate(Associate associate) throws  SQLException{
		try{

			PreparedStatement psmt1=conn.prepareStatement("insert into associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId)values(?,?,?,?,?,?,?)");
			psmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			psmt1.setString(2, associate.getFirstName());			
			psmt1.setString(3, associate.getLastName());			
			psmt1.setString(4, associate.getDepartment());			
			psmt1.setString(5, associate.getDesignation());			
			psmt1.setString(6, associate.getPancard());			
			psmt1.setString(7, associate.getEmailId());			
			psmt1.executeUpdate();

			PreparedStatement pstmt2 = conn.prepareStatement("select max(associateId) from Associate");
			ResultSet rs = pstmt2.executeQuery();
			rs.next();
			int associateId = rs.getInt(1);

			PreparedStatement psmt3=conn.prepareStatement("insert into bankdetails(associateId,accountNumber,bankName,ifscCode)values(?,?,?,?)");
			psmt3.setInt(1, associateId);
			psmt3.setInt(2, associate.getBankdetails().getAccountNumber());
			psmt3.setString(3, associate.getBankdetails().getBankName());
			psmt3.setString(4, associate.getBankdetails().getIfscCode());
			psmt3.executeUpdate();

			PreparedStatement psmt4=conn.prepareStatement("insert into salary(associateId,basicSalary,epf,companyPf) values(?,?,?,?)");
			psmt4.setInt(1, associateId);
			psmt4.setDouble(2,  associate.getSalary().getBasicSalary());
			psmt4.setDouble(3, associate.getSalary().getEpf());
			psmt4.setDouble(4, associate.getSalary().getCompanyPf());
			psmt4.executeUpdate();

			conn.commit();
			return associateId;
		}
		catch(SQLException e){
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
	}

	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement psmt1=conn.prepareStatement("update associate set yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateId=?");
			psmt1.setInt(1, associate.getYearlyInvestmentUnder80C());
			psmt1.setString(2, associate.getFirstName());			
			psmt1.setString(3, associate.getLastName());			
			psmt1.setString(4, associate.getDepartment());			
			psmt1.setString(5, associate.getDesignation());			
			psmt1.setString(6, associate.getPancard());			
			psmt1.setString(7, associate.getEmailId());		
			psmt1.setInt(8, associate.getAssociateId());			
			psmt1.executeUpdate();

			PreparedStatement pstmt2 = conn.prepareStatement("update salary set basicSalary=?,hra=?,conveyenceAllowance=?,otherAllowance=?,personalAllowance=?,monthlyTax=?,epf=?,companyPf=?,gratuity=?,grossSalary=?,netSalary=?");
			pstmt2.setDouble(1,associate.getSalary().getBasicSalary());
			pstmt2.setDouble(2, associate.getSalary().getHra());
			pstmt2.setDouble(3, associate.getSalary().getConveyenceAllowance());
			pstmt2.setDouble(4, associate.getSalary().getOtherAllowance());
			pstmt2.setDouble(5, associate.getSalary().getPersonalAllowance());
			pstmt2.setDouble(6, associate.getSalary().getMonthlyTax());
			pstmt2.setDouble(7, associate.getSalary().getEpf());
			pstmt2.setDouble(8, associate.getSalary().getCompanyPf());
			pstmt2.setDouble(9, associate.getSalary().getGratuity());
			pstmt2.setDouble(10, associate.getSalary().getGrossSalary());
			pstmt2.setDouble(11, associate.getSalary().getNetSalary());
			pstmt2.setInt(12, associate.getAssociateId());			
			pstmt2.executeUpdate();

			PreparedStatement pstmt3 = conn.prepareStatement("upadate bankdetails set accountNumber=?,bankName=?,ifscCode=?");
			pstmt3.setInt(1, associate.getBankdetails().getAccountNumber());
			pstmt3.setString(2, associate.getBankdetails().getBankName());
			pstmt3.setString(3, associate.getBankdetails().getIfscCode());
			pstmt3.setInt(4, associate.getAssociateId());			
			pstmt3.executeUpdate();
			conn.commit();

		}
		catch(SQLException e){
			conn.rollback();
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}
		return true;
	}


	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		try{
			conn.setAutoCommit(false);
			PreparedStatement pstmt1 = conn.prepareStatement("delete from associate where associateId=?");
			pstmt1.setInt(1, associateId);
			pstmt1.executeUpdate();
			conn.commit();
			return true;
		}catch(SQLException e){
			e.printStackTrace();
			conn.rollback();
			return false;
		}
		finally {
			conn.setAutoCommit(true);
		}

	}

	@Override  
	public Associate getAssociate(int associateId) throws SQLException {
		PreparedStatement pstmt1 = conn.prepareStatement("select a.associateId,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,c.accountNumber,c.bankName,c.ifscCode from associate a inner join salary b inner join  bankdetails c on	a.associateID=b.associateId and	a.associateId=c.associateId where associateId=?");
		pstmt1.setInt(1, associateId);
		ResultSet rs = pstmt1.executeQuery();
		if(rs.next()){
			return new Associate(associateId, rs.getInt("yearlyInvestmentUnder80C"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"), new Salary(rs.getDouble("basicSalary"), rs.getDouble("hra"), rs.getDouble("conveyenceAllowance"), rs.getDouble("otherAllowance"), rs.getDouble("personalAllowance"), rs.getDouble("monthlyTax"), rs.getDouble("epf"), rs.getDouble("companyPf"),rs.getDouble("gratuity"),rs.getDouble("grossSalary"), rs.getDouble("netSalary")),new BankDetails(rs.getInt("accountNumber"),  rs.getString("bankName"),  rs.getString("ifscCode")));
		}
		return null;	
	}

	@Override
	public List<Associate> getAssociate() throws SQLException {
		ArrayList<Associate> associates = new ArrayList<>();
		PreparedStatement pstmt1 = conn.prepareStatement("select a.associateId,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,c.accountNumber,c.bankName,c.ifscCode from associate a inner join salary b inner join  bankdetails c on	a.associateID=b.associateId and	a.associateId=c.associateId where associateId=?");
		ResultSet rs = pstmt1.executeQuery();
		while(rs.next()){
			associates.add(new Associate(rs.getInt("associateId"), rs.getInt("yearlyInvestmentUnder80C"), rs.getString("firstName"), rs.getString("lastName"), rs.getString("department"), rs.getString("designation"), rs.getString("pancard"), rs.getString("emailId"), new Salary(rs.getDouble("basicSalary"), rs.getDouble("hra"), rs.getDouble("conveyenceAllowance"), rs.getDouble("otherAllowance"), rs.getDouble("personalAllowance"), rs.getDouble("monthlyTax"), rs.getDouble("epf"), rs.getDouble("companyPf"),rs.getDouble("gratuity"),rs.getDouble("grossSalary"), rs.getDouble("netSalary")),new BankDetails(rs.getInt("accountNumber"),  rs.getString("bankName"),  rs.getString("ifscCode"))));
		}
		return associates;
	}
	 */


}